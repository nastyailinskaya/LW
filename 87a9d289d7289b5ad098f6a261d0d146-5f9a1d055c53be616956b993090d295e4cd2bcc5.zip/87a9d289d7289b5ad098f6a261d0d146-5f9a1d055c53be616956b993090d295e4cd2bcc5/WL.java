import java.util.Scanner;
import java.util.ArrayList;

class ThirdProblem {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Double> arr = new ArrayList<Double>();

        int arrSize;
        arrSize = sc.nextInt();

        for (int i = 0; i < arrSize; i++) {
            arr.add(sc.nextDouble());
        }

        System.out.println("Начальный массив: ");
        for (Double aDouble : arr) {
            System.out.print(aDouble + " ");
        }
        System.out.println();

        int currentIndex = 1;
        for (int i = 1; i < arrSize; i++) {
            if (arr.get(currentIndex) < arr.get(currentIndex - 1)) {
                arr.remove(currentIndex);
            } else currentIndex++;
        }
        System.out.println();

        System.out.println("Обработанный массив: ");
        for (Double aDouble : arr) {
            System.out.print(aDouble + " ");
        }
    }
}

class SecondProblem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arrSize;
        int toRemove;

        try {
            arrSize = sc.nextInt();
            ArrayList<Integer> arr = new ArrayList<Integer>();
            for (int i = 0; i < arrSize; i++) {
                arr.add(sc.nextInt());
            }
            toRemove = sc.nextInt();

            System.out.println("Начальный массив: ");
            for (int i = 0; i < arrSize; i++) {
                System.out.print(arr.get(i) + " ");
            }
            System.out.println();

            int curIndex = 0;
            for (int i = 0; i < arrSize; i++) {
                if (arr.get(curIndex) == toRemove) {
                    arr.remove(curIndex);
                } else {
                    curIndex++;
                }
            }

            System.out.println("Обработанный массив: ");
            for (int aInt : arr) {
                System.out.print(aInt + " ");
            }



    }
}